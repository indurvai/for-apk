package com.notifytrace.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Append-only JSON-Lines history (one notification per line) plus a tiny per-app icon cache.
 * Icons are stored once per package instead of inside every record, which keeps the file small.
 */
object HistoryStore {
    private const val HISTORY_FILE = "notifytrace_history.jsonl"
    private const val ICON_DIR = "icons"
    const val RETENTION_MS = 365L * 24L * 60L * 60L * 1000L
    private const val MAX_RETURNED = 5000
    private const val MAX_STORED_LINES = 40000

    private val lock = Any()
    private var appendsSinceCompact = 0

    private fun file(ctx: Context) = File(ctx.filesDir, HISTORY_FILE)

    fun append(ctx: Context, record: JSONObject) {
        synchronized(lock) {
            file(ctx).appendText(record.toString() + "\n")
            appendsSinceCompact++
            if (appendsSinceCompact >= 500) compact(ctx)
        }
    }

    /** Newest first, de-duplicated by id (later updates of a notification win), within 365 days. */
    fun readRecent(ctx: Context, limit: Int = MAX_RETURNED): JSONArray {
        val out = JSONArray()
        synchronized(lock) {
            val f = file(ctx)
            if (!f.exists()) return out
            val cutoff = System.currentTimeMillis() - RETENTION_MS
            val seen = HashSet<String>()
            val lines = try { f.readLines() } catch (e: Exception) { return out }
            for (i in lines.indices.reversed()) {
                val line = lines[i]
                if (line.isBlank()) continue
                try {
                    val obj = JSONObject(line)
                    if (obj.optLong("timestamp", 0L) < cutoff) continue
                    if (!seen.add(obj.optString("id"))) continue
                    out.put(obj)
                    if (out.length() >= limit) break
                } catch (e: Exception) {
                    // skip corrupt line
                }
            }
        }
        return out
    }

    /** Drop records older than 365 days and trim to the newest MAX_STORED_LINES. */
    fun compact(ctx: Context) {
        synchronized(lock) {
            appendsSinceCompact = 0
            val f = file(ctx)
            if (!f.exists()) return
            try {
                val cutoff = System.currentTimeMillis() - RETENTION_MS
                val kept = ArrayList<String>()
                for (line in f.readLines()) {
                    if (line.isBlank()) continue
                    try {
                        if (JSONObject(line).optLong("timestamp", 0L) >= cutoff) kept.add(line)
                    } catch (e: Exception) { /* drop corrupt */ }
                }
                val trimmed = if (kept.size > MAX_STORED_LINES) kept.subList(kept.size - MAX_STORED_LINES, kept.size) else kept
                val tmp = File(ctx.filesDir, "$HISTORY_FILE.tmp")
                tmp.writeText(if (trimmed.isEmpty()) "" else trimmed.joinToString("\n", postfix = "\n"))
                if (!tmp.renameTo(f)) {
                    f.writeText(tmp.readText())
                    tmp.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun iconFile(ctx: Context, pkg: String): File {
        val dir = File(ctx.filesDir, ICON_DIR)
        if (!dir.exists()) dir.mkdirs()
        return File(dir, pkg.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".txt")
    }

    fun saveIconIfMissing(ctx: Context, pkg: String, drawable: Drawable?) {
        if (drawable == null) return
        val f = iconFile(ctx, pkg)
        if (f.exists()) return
        try {
            val size = 72
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            drawable.setBounds(0, 0, size, size)
            drawable.draw(canvas)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
            bmp.recycle()
            f.writeText("data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
        } catch (e: Exception) {
            // no icon is fine
        }
    }

    /** { packageName: dataUri } for every app seen so far. */
    fun readIconMap(ctx: Context): JSONObject {
        val map = JSONObject()
        val dir = File(ctx.filesDir, ICON_DIR)
        val files = dir.listFiles() ?: return map
        // file names are sanitised package names; packages normally contain only safe characters
        for (f in files) {
            try {
                map.put(f.name.removeSuffix(".txt"), f.readText())
            } catch (e: Exception) { /* skip */ }
        }
        return map
    }
}
