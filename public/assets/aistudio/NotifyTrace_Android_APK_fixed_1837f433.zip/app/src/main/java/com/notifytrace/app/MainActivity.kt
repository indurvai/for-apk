package com.notifytrace.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var pageLoaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
            }
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        webView.loadUrl("file:///android_asset/index.html")

        // First launch only: jump straight to the permission screen. After that the page shows a banner.
        val prefs = getSharedPreferences("notifytrace", MODE_PRIVATE)
        if (!isNotificationListenerEnabled() && !prefs.getBoolean("asked_access", false)) {
            prefs.edit().putBoolean("asked_access", true).apply()
            openAccessSettings()
        }
    }

    override fun onResume() {
        super.onResume()
        // Live updates while the screen is open
        NotifyTraceListenerService.onNewNotificationCallback = { jsonStr ->
            runOnUiThread {
                val escaped = JSONObject.quote(jsonStr)
                webView.evaluateJavascript(
                    "if(window.onNativeNotificationPosted) window.onNativeNotificationPosted($escaped);", null
                )
            }
        }
        // Catch up on anything captured while the app was in the background / after returning from Settings
        if (pageLoaded) {
            webView.evaluateJavascript("if(window.refreshFromNative) window.refreshFromNative();", null)
        }
    }

    override fun onPause() {
        NotifyTraceListenerService.onNewNotificationCallback = null
        super.onPause()
    }

    override fun onDestroy() {
        NotifyTraceListenerService.onNewNotificationCallback = null
        webView.destroy()
        super.onDestroy()
    }

    private fun isNotificationListenerEnabled(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            openAppInfo()
        }
    }

    private fun openAppInfo() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun getHistoricalNotifications(): String =
            HistoryStore.readRecent(applicationContext).toString()

        @JavascriptInterface
        fun getAppIcons(): String = HistoryStore.readIconMap(applicationContext).toString()

        @JavascriptInterface
        fun openNotificationAccessSettings() {
            runOnUiThread { openAccessSettings() }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread { this@MainActivity.openAppInfo() }
        }

        @JavascriptInterface
        fun isServiceEnabled(): Boolean = isNotificationListenerEnabled()
    }
}
