# NotifyTrace — Native Android APK Project (365-Day Real Notification History)

Why a web page or downloaded `.html` file cannot read your phone's notifications:
1. When an `.html` file is opened locally (`file:///...`), Chrome hides **Add to Home Screen** and sandboxes the file from Android OS services.
2. Reading real notifications from other apps on Android (WhatsApp, Gmail, System, Messenger, etc.) requires a native Android `NotificationListenerService` with the system permission `android.permission.BIND_NOTIFICATION_LISTENER_SERVICE`.

This project wraps the **NotifyTrace** UI inside a native Android app with `NotifyTraceListenerService.kt`, which captures every notification posted on your phone, extracts the real app icon via `PackageManager.getApplicationIcon()`, stores 365 days of history locally on your phone, and streams them into the NotifyTrace inspector.

## Option 1: Build the APK in the Cloud Without Installing Anything (GitHub Actions)
1. Upload the contents of this folder to a new free GitHub repository.
2. Click the **Actions** tab and run **Build NotifyTrace Android APK** (it also runs on every push).
3. When it finishes, open the repo's **Releases** page on your phone and download **NotifyTrace.apk** (or take `app-debug.apk` from the run's Artifacts) and install it.

## Option 2: Build in Android Studio
1. Open this folder in **Android Studio**.
2. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
3. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it.

## Enabling Real Phone Notification Capture After Installing the APK
1. Open **NotifyTrace**. A banner appears while notification access is OFF.
2. Tap **Open Notification Access** and switch **NotifyTrace** ON.
3. If the switch is greyed out / "Restricted setting" (Android 13+ for apps installed from outside the Play Store): tap **Open App Info**, press the 3-dot menu (top right) -> **Allow restricted settings**, then repeat step 2.
4. On first enable, everything currently in your notification shade is captured immediately; from then on every new notification is saved for 365 days.

Important limits
- Android has no API to read notifications that arrived *before* access was granted (and already got dismissed). History starts when you switch access on.
- If your phone kills background apps aggressively (Xiaomi, Oppo, Vivo, Samsung "sleeping apps"), set NotifyTrace battery usage to **Unrestricted** and lock it in Recents so capture isn't interrupted.
- The app no longer requests Internet permission: all data stays on the phone.
